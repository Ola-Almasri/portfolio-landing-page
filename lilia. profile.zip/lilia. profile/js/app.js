$(function () {
    "use strict";
    
    var $window = $(window),
        $htmlBody = $("html, body"),
        $btnScrollTop = $(".scroll-top"),
        $mainNavbar = $(".navbar"),
        hasCounted = false;
        
    $(".loading").animate({
        "top": "-100%" 
    }, 700, function () {
        $(this).remove();
    });
    
    function updateNavbar() {
        if ($window.scrollTop() > 20) {
            $mainNavbar.addClass("active-nav");
        } else {
            $mainNavbar.removeClass("active-nav");
        }
    }
    
    updateNavbar();
    
    $window.on("scroll", function () {
        updateNavbar();
    });
    
    $(".navbar .menu-toggle").on("click", function () {
        $mainNavbar.toggleClass("menu-active");
    });
    
    $(".navbar .navbar-nav > li:not('.nav-brand') > a").on("click", function (e) {
        if ($(this).attr('href').charAt(0) === "#") {
            e.preventDefault();
        }
        var $link = $(this);
        $htmlBody.animate({
            scrollTop: $($link.attr("href")).offset().top - 62
        }, 600);
    });
    
    $window.on("scroll", function () {
        $("section").each(function () {
            if ($window.scrollTop() >= $(this).offset().top - 63) {
                $(".navbar .navbar-nav > li > a[href='#" + $(this).attr("id") + "']")
                    .addClass("active")
                    .parent().siblings().find("a").removeClass("active");
            }
        });
    });
	
    $(".home .main-btn, .call-to-action .main-btn").on("click", function (e) {
        if ($(this).attr('href').charAt(0) === "#") {
            e.preventDefault();
        }
        var $link = $(this); 
        $htmlBody.animate({
            scrollTop: $($link.attr("href")).offset().top - 62
        }, 800);
    });
	
    $(".header .main-btn").on("click", function (e) {
        if ($(this).attr('href').charAt(0) === "#") {
            e.preventDefault();
        }
        var $link = $(this); 
        $htmlBody.animate({
            scrollTop: $($link.attr("href")).offset().top
        }, 800);
    });
	
    function toggleScrollTop() {
        if ($window.scrollTop() >= 1100) {
            $btnScrollTop.addClass("active");
        } else {
            $btnScrollTop.removeClass("active");
        }
    }
    
    toggleScrollTop();
    
    $window.on("scroll", function () {
        toggleScrollTop();
    });
    
    $btnScrollTop.on("click", function (e) {
        e.preventDefault();
        $htmlBody.animate({
            scrollTop: 0
        }, 800);
    });
    
    $("#control li").on('click', function () {
        $(this).addClass('active').siblings("li").removeClass('active');
    });

    $('#filtr-container').filterizr({
        animationDuration: 0.4
    });
    
    if ($('.portfolio-content .item')[0]) {
        $('.portfolio-content .item').magnificPopup({
            delegate: '.icon-img',
            type: 'image',
            gallery: { enabled: true }
        });
    }
    
    if (!hasCounted && $(this).scrollTop() >= $(".counters").offset().top - 400) {
        $(".counters .counter-number").countTo();
        hasCounted = true;
    }
    
    $window.on("scroll", function () {
        if (!hasCounted && $(this).scrollTop() >= $(".counters").offset().top - 400) {
            $(".counters .counter-number").countTo();
            hasCounted = true;
        }
    });
    
    $(".testimonials .owl-carousel").owlCarousel({
        items: 3,
        autoplay: true,
        smartSpeed: 500,
        margin: 30,
        loop: true,
        autoplayHoverPause: true,
        responsiveClass: true,
        responsive: {
            0: { items: 1 },
            991: { items: 3 }
        }
    });
	
    $('.contact-form').on("submit", function () {
        var $form = $(this),
            formData = {};
        
        $form.find('[name]').each(function() {
            var $input = $(this),
                name = $input.attr('name'),
                value = $input.val();
            formData[name] = value;
        });
        
        $.ajax({
            url: $form.attr('action'),
            type: $form.attr('method'),
            data: formData,
            success: function (response) {
                if (response == "success") {
                    $(".contact-form").find(".form-message").addClass("success");
                    $(".form-message span").text("Message Sent!");
                } else {
                    $(".contact-form").find(".form-message").addClass("error");
                    $(".form-message span").text("Error Sending!");
                }
            }
        });
        
        return false;
    });
    
    new WOW().init();
});
ىن