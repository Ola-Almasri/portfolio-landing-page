document.addEventListener('DOMContentLoaded', function () {
  
    var addToCartButtons = document.querySelectorAll('.add-to-cart');
    var successMessage   = document.getElementById('success-message');
    var cartCount        = document.getElementById('cart-count');
    var cartItems        = 0;
    addToCartButtons.forEach(function (button) {
        button.addEventListener('click', function () {
            successMessage.classList.add('show');
            setTimeout(function () {
                successMessage.classList.remove('show');
            }, 2500);
            cartItems++;
            cartCount.textContent = cartItems;
        });
    });
});

