<?php
//تدمير السيشن
session_start();//بدء الجسة
session_destroy();//تدمير الجلسة
setcookie("userEmail", $email, time() - 31536000, "/");//تدمير الكوكي
header("Location: login.php");
exit;
?>
