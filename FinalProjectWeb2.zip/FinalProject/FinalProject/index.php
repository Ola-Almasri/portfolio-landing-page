<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome to Al Hayat Hospital</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background: linear-gradient(to right, #eaf4fc, #d4e9f9);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            height: 100vh;
        }

        .navbar {
            width: 97%;
            background-color: #1a73e8;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            position: fixed;
            top: 0;
            left: 0;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            z-index: 1000;
        }

        .navbar div {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 5px;
        }

        .navbar a {
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 5px 10px;
            margin: 0;
        }

        .navbar .links {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .navbar .links a {
            color: #fff;
            text-decoration: none;
            font-weight: 500;
            font-size: 1rem;
            padding: 5px 10px;
            margin: 0;
        }

        .navbar span {
            margin-left: 10px;
            font-size: 1.2rem;
            font-weight: bold;
        }

        .container {
            margin-top: 0;
            display: flex;
            align-items: stretch;
            justify-content: space-between;
            width: 100%;
            max-width: 100%;
            height: calc(120vh - 60px);
            overflow: hidden;
            background-color: transparent;
        }

        .image-section {
            flex: 1;
            background: url('./c6d9c67c2abec7ad466f22f6558144b5.jpg') no-repeat center;
            background-size: cover;
            height: 500px;
            min-height: 100%;
        }

        .text-section {
            flex: 1;
            padding: 40px;
            display: flex;
            flex-direction: column;
            justify-content: center;
            text-align: center;
        }

        .text-section h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1a73e8;
            margin-bottom: 10px;
        }

        .text-section p {
            font-size: 1.2rem;
            color: #555;
            margin-bottom: 20px;
        }

        .contact-info {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #777;
        }

        .contact-info span {
            display: block;
            margin-bottom: 5px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 1.5rem;
            font-weight: bold;
        }

        .logo i {
            font-size: 1.8rem;
            color: #fff;
        }

        .extra-info {
            margin-top: 20px;
            font-size: 0.9rem;
            color: #555;
            text-align: center;
        }

        .stats {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-top: 10px;
        }

        .stats div {
            text-align: center;
        }

        .stats h3 {
            font-size: 1.2rem;
            color: #1a73e8;
            margin: 0;
        }

        .stats p {
            font-size: 0.9rem;
            color: #555;
        }
    </style>
</head>
<body>
<div class="navbar">
    <div class="logo">
        <i class="fas fa-stethoscope"></i>
        <span>Al Hayat Hospital</span>
    </div>
    <div class="links">
        <a href="login.php">Login</a>
        <a href="register.php">Register</a>
    </div>
</div>
<div class="container">
    <div class="text-section">
        <h1>Welcome to Al Hayat Hospital</h1>
        <p>Your journey to better health starts here.</p>
        <div class="contact-info">
            <span>📞 Phone: +972 456 7892</span>
            <span>✉️ Email: contact@alhayathospital.com</span>
        </div>
        <div class="extra-info">
            <p>Your trusted partner in health and wellness.</p>
            <div class="stats">
                <div>
                    <h3>50+</h3>
                    <p>Doctors</p>
                </div>
                <div>
                    <h3>20</h3>
                    <p>Departments</p>
                </div>
                <div>
                    <h3>15+</h3>
                    <p>Years of Experience</p>
                </div>
            </div>
        </div>
    </div>
    <div class="image-section"></div>
</div>
</body>
</html>












