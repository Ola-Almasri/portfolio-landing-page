<?php
session_start(); // بدء الجلسة لتخزين و استرجاع البيانات الخاصة بالمستخدم
include 'db.php';

if (!isset($_SESSION['patient_id'])) { // لو كانت الجلسة ما بتحتوي على البيشنت اي دي
    header("Location: login.php"); // هيرجع المستخدم على صفحة اللوجن
    exit(); // انتهاء السكريبت
}
$patient_id = $_SESSION['patient_id']; // استرجاع البيشنت اي دي المخزن في جلسة البيشنت اي دي
$sql = "SELECT * FROM patients WHERE id = '$patient_id'"; // استعلام لجلب بيانات المريض من جدول البيشنت باستخدام  الاي دي بيشنت
// $stmt = $conn->prepare($sql);
// if (!$stmt) {
//     die("Failed to prepare statement: " . $conn->error);
// }

// $stmt->bind_param("i", $patient_id);
// $stmt->execute();

$result = mysqli_query($conn, $sql); // تنفيذ الاستعلام
if (!$result) { // التحقق من نجاح الاستعلام
    error_log("Error executing query: " . mysqli_error($conn)); // تسجيل الخطأ مع تفاصيله
    die("<div class='alert alert-danger'>Patient not found. Please contact support.</div>");// طباعة رسالة الخطأ للمستخدم

}

if ($result && $result->num_rows > 0) { // التحقق من وجود بيانات
    $patient = $result->fetch_assoc(); // هجيب بيانات المريض كصف واحد
} else {
    // لو ما لقى بيانات هيطبع رسالة الخطأ هاي وينهي السكريبت
    echo "<div class='alert alert-danger'>Patient not found in the database. Please contact support.</div>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f2f6f9; 
            font-family: 'Poppins', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .dashboard-card {
            width: 360px;
            background-color: #ffffff;
            border-radius: 15px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }
        .dashboard-header {
            background-color: #88c0d0;
            color: white;
            padding: 20px;
            text-align: center;
            font-size: 18px;
            font-weight: bold;
            position: relative;
        }
        .dashboard-header .logout-icon {
            position: absolute;
            top: 21px;
            right: 15px;
            font-size: 20px;
            color: white;
            cursor: pointer;
            transition: transform 0.2s;
        }
        .dashboard-header .logout-icon:hover {
            transform: scale(1.2);
        }
        .dashboard-body {
            padding: 20px;
        }
        .profile-item {
            display: flex;
            align-items: center;
            margin-bottom: 10px;
            font-size: 14px;
            color: #555555; 
        }
        .profile-item i {
            font-size: 18px;
            color: #88c0d0; 
            margin-right: 8px;
        }
        .btn-update {
            display: block;
            width: 70%;
            margin: 0 auto;
            background-color: #8fbcbb; 
            color: white;
            font-size: 12px; 
            font-weight: bold;
            border-radius: 8px; 
            text-align: center;
            padding: 6px; 
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .btn-update:hover {
            background-color: #6a9a99; 
        }
    </style>
</head>
<body>
    <div class="dashboard-card">
        <div class="dashboard-header">
            Welcome, <?php echo htmlspecialchars($patient['name']); ?>
            <a href="logout.php" class="logout-icon"><i class="bi bi-box-arrow-right"></i></a>
        </div>
        <div class="dashboard-body">
            <div class="profile-item"><i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($patient['name']); ?></div>
            <div class="profile-item"><i class="bi bi-envelope"></i> <?php echo htmlspecialchars($patient['email']); ?></div>
            <div class="profile-item"><i class="bi bi-telephone"></i> <?php echo htmlspecialchars($patient['phone_number']); ?></div>
            <div class="profile-item"><i class="bi bi-gender-ambiguous"></i> <?php echo htmlspecialchars($patient['gender']); ?></div>
            <div class="profile-item"><i class="bi bi-calendar"></i> Age: <?php echo htmlspecialchars($patient['age']); ?></div>
            <div class="profile-item"><i class="bi bi-exclamation-circle"></i> <?php echo htmlspecialchars($patient['problem']); ?></div>
            <div class="profile-item"><i class="bi bi-calendar2-event"></i> <?php echo htmlspecialchars($patient['entranceDate']); ?></div>
            <a href="update_patient.php?patient_id=<?php echo $patient_id; ?>" class="btn-update mt-3">Update Profile</a>
            </div>
    </div>
</body>
</html>




















