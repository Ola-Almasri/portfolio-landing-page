<?php
session_start(); // بدء الجلسة
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات
$errors = []; // مصفوفة فارغة لتخزين رسايل الخطأ
//بيشيك إذا كان الطلب الى جاي من الفورم هو من نوع POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // هنا يتم التحقق من القيم المدخلة
    $name = trim($_POST['name']); // استرجاع الاسم وازالة المسافات
    $email = trim($_POST['email']); // استرجاع الايميل وازالة المسافات
    $password = trim($_POST['password']); // استرجاع كلمة السر وازالة المسافات
    $phone_number = trim($_POST['phone_number']); // استرجاع رقم الهاتف وازالة المسافات
    $role = trim($_POST['role']); // استرجاع الدور وازالة المسافات

    if (empty($name)) { // بدي افحص لو كان الاسم فارغ
        $errors['name'] = "Full Name is required."; // هتتخزن رسالة الخطأ بالمصفوفة  بانو الاسم كامل مطلوب
    }
    if (empty($email)) { // بدي افحص لو كان الايميل فارغ
        $errors['email'] = "Email is required."; // هتتخزن رسالة الخطأ بالمصفوفة بانو الايميل مطلوب
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // بدي اتحقق هل الايميل يلي دخلو المستخدم صالح
        $errors['email'] = "Invalid email format."; // ولو مش صالح هتتخزن رسالة الخطأ بالمصفوفة
    } else {
        // التحقق من وجود البريد الإلكتروني في قاعدة البيانات
        $sql_check_email = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $sql_check_email);
        if (mysqli_num_rows($result) > 0) {
            $errors['email'] = "Email is already taken."; // إذا كان البريد موجودًا
        }
    }
    if (empty($password)) { // بدي افحص لو الباسوورد لو كان فارغ
        $errors['password'] = "Password is required."; // هتتخزن رسالة الخطأ بالمصفوفة بانو الباسوررد مطلوب
    }
    if (empty($phone_number)) { // بدي افحص لو رقم الهاتف  كان فارغ
        $errors['phone_number'] = "Phone Number is required."; // هتتخزن رسالة الخطأ بالمصفوفة بأنو رقم الهاتف مطلوب
    }
    if (empty($role)) { // بدي افحص لو الدور كان فارغ
        $errors['role'] = "Role is required."; // ختتخزن رسالة الخطأ بالمصفوفة بأنو الدور مطلوب
    }
if (empty($errors)) { //لو مصفوفة الخطأ كانت فارغة  يعني ما فيها اخطاء
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);// تشفير كلمة السر يلي دخلها المستخدم

    // الاستعلام هادا بضيف بيانات المستخدم في جدول users في قاعدة البيانات.
         $sql_users = "INSERT INTO users (name, email, password, phone_number, role) VALUES ('$name', '$email', '$hashed_password', '$phone_number', '$role')";
         //// تنفيذ الاستعلام وإدخال البيانات في قاعدة البياناتوفي حالة حدوث خطأ بتم إيقاف التنفيذ وعرض رسالة الخطأ
         if (!mysqli_query($conn, $sql_users)) {
            die("Error: " . mysqli_error($conn));
         }
        // اذا كان الدور دكتور بتم تخزين البيانات في جدول الدكتور
        if ($role === 'doctor') {
            $sql_doctor = "INSERT INTO doctors (name, email, password, phone_number) VALUES ('$name', '$email', '$hashed_password', '$phone_number')";
            mysqli_query($conn, $sql_doctor);//تنفيذ الاستعلام
        // اذا كان الدور صيدلي بتم تخزين البيانات في جدول الصيدلي
        } elseif ($role === 'pharmacist') {
            $sql_pharmacist = "INSERT INTO pharmacists (name, email, password, phone_number) VALUES ('$name', '$email', '$hashed_password', '$phone_number')";
            mysqli_query($conn, $sql_pharmacist);//تنفيذ الاستعلام
        }
        // إنشاء جلسة وتخزين بيانات المستخدم فيها
        $_SESSION['name'] = $name; // تخزين الاسم في الجلسة
        $_SESSION['email'] = $email; // تخزين الايميل في الجلية
        $_SESSION['role'] = $role; // تخزين الدور في الجلسة

        setcookie("userEmail", $email, time() + 31536000, "/"); // تخزين الكوكي

        //  إظهار رسالة نجاح وإعادة التوجيه لصفحة الاندكس
        echo "<script>
                alert('Registration successful! You can now log in.');
                window.location.href = 'index.php';
              </script>";
        exit(); // انهاء السكريبت
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .register-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f4f8;
        }
        .register-card {
            max-width: 1100px;
            width: 100%;
            display: flex;
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
        }
        .register-image {
            flex: 1;
            background: url('./5ef98be88defde9c6dab278927d4d122.jpg') no-repeat center;
            background-size: 350px;
        }
        .register-form {
            flex: 1;
            padding: 50px;
        }
        .register-header {
            font-size: 24px;
            font-weight: bold;
            color: #74b9ff;
            margin-bottom: 20px;
            text-align: center;
        }
        .input-group-text {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .btn-primary {
            font-size: 16px;
            background-color: #007bff;
            border: none;
            transition: all 0.3s ease;
            font-weight: bold;
            border-radius: 15px;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .text-danger {
            font-size: 13px;
            position: relative;
            top: -8px;
            left: 5px;
            color: #ff4d4f;
            font-weight: 500;
        }
        input::placeholder {
            font-size: 12px; 
            color: #aaa;
            font-style: normal; 
        }
        .input-group .form-select {
            font-size: 14px; 
            padding: 4px 8px; 
            border-radius: 5px;
        }
        .input-group-text {
            font-size: 24px;
            padding: 4px 8px;
            border-radius: 5px 0 0 5px;
        }
    </style>
</head>
<body>
<div class="register-container">
    <div class="register-card">
        <!-- قسم الصورة -->
        <div class="register-image"></div>

        <!-- قسم النموذج -->
        <div class="register-form">
            <h2 class="register-header">Create Your Account</h2>

            <!-- عرض رسالة الخطأ العامة إذا وجدت -->
            <?php if (!empty($message)): ?>
                <div class="alert alert-danger text-center"><?php echo $message; ?></div>
            <?php endif; ?>

            <form action="register.php" method="POST">
                <!-- Full Name -->
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-person"></i></span>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Enter your full name" value="<?php echo isset($name) ? $name : ''; ?>">
                </div>
                <?php if (!empty($errors['name'])): ?>
                    <span class="text-danger"><?php echo $errors['name']; ?></span>
                <?php endif; ?>

                <!-- Email -->
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                    <input type="email" name="email" id="email" class="form-control" placeholder="Enter your email" value="<?php echo isset($email) ? $email : ''; ?>">
                </div>
                <?php if (!empty($errors['email'])): ?>
                    <span class="text-danger"><?php echo $errors['email']; ?></span>
                <?php endif; ?>

                <!-- Password -->
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-lock"></i></span>
                    <input type="password" name="password" id="password" class="form-control" placeholder="Enter your password">
                </div>
                <?php if (!empty($errors['password'])): ?>
                    <span class="text-danger"><?php echo $errors['password']; ?></span>
                <?php endif; ?>

                <!-- Phone Number -->
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-telephone"></i></span>
                    <input type="text" name="phone_number" id="phone_number" class="form-control" placeholder="Enter your phone number" value="<?php echo isset($phone_number) ? $phone_number : ''; ?>">
                </div>
                <?php if (!empty($errors['phone_number'])): ?>
                    <span class="text-danger"><?php echo $errors['phone_number']; ?></span>
                <?php endif; ?>

                <!-- Role -->
                <div class="mb-3 input-group">
                    <span class="input-group-text"><i class="bi bi-people"></i></span>
                    <select name="role" id="role" class="form-select">
                        <option value="">Select Role</option>
                        <option value="doctor" <?php echo (isset($role) && $role === 'doctor') ? 'selected' : ''; ?>>Doctor</option>
                        <option value="pharmacist" <?php echo (isset($role) && $role === 'pharmacist') ? 'selected' : ''; ?>>Pharmacist</option>
                    </select>
                </div>
                <?php if (!empty($errors['role'])): ?>
                    <span class="text-danger"><?php echo $errors['role']; ?></span>
                <?php endif; ?>

                <!-- Submit Button -->
                <button type="submit" class="btn btn-primary w-100">Register</button>
            </form>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body> 
</html>



