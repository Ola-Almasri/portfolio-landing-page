<?php
session_start(); // بدء الجلسة
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات
// echo "Session User ID: " . $_SESSION['user_id']; // تحقق من قيمة الجلسة

//التحقق من تسجيل دخول الطبيب
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'doctor') {
    header("Location: login.php"); // لو الدور ما كان طبيب هيرجعو على صفحة اللوجن
    exit(); // انتهاء السكريبت
}
// التحقق من وجود اسم المستخدم واي دي الدكتور في الجلسة
if (!isset($_SESSION['name']) || !isset($_SESSION['user_id'])) {
    header("Location: login.php"); // هيرجع ايضا الى اللوجن لو ما لقى البيانات
    exit(); // انتهاء السكريبت
}
// هججيب بيانات الدكتور من الجلسة
$name = $_SESSION['name']; // اسم الدكتور
$doctor_id = $_SESSION['user_id']; // اي دي الدكتور

//  هجيب بيانات المرضى من جدول البيشنت المرتبطين بالطبيب يلي مسجلة دخول فيه و ربطنا من خلال جدول الوصلة البيشنت دكتور من خلال اي دي البيشنت والدكتور
$sql = "SELECT patients.* FROM patients 
        INNER JOIN patientdoctor ON patients.id = patientdoctor.pat_id 
        WHERE patientdoctor.doc_id = $doctor_id";
$result = $conn->query($sql); // تنفيذ الاستعلام

if (isset($_GET['deleted']) && $_GET['deleted'] == 'true') { 
    echo '<div class="alert alert-success text-center">patient deleted successfully.</div>'; 
} elseif (isset($_GET['error'])) { 
    echo '<div class="alert alert-danger text-center">' . htmlspecialchars($_GET['error']) . '</div>'; 
} elseif (isset($_GET['error'])) {
    echo '<div class="alert alert-danger text-center">' . htmlspecialchars($_GET['error']) . '</div>';
} elseif (isset($_GET['success']) && $_GET['success'] == 'patient added successfully') {
    echo '<div class="alert alert-success text-center">patient added successfully.</div>';
} elseif (isset($_GET['updated']) && $_GET['updated'] == 'true') {
    echo '<div class="alert alert-success text-center">Patient updated successfully.</div>';
}

if (!$result) { // التحقق هل الاستعلام ناجح؟
    die("Error fetching patients: " . $conn->error); // هيعرضلي رسالة الخطأ هاي لو فشل الاستعلام
}

// التحقق من قائمة المرضى هل يوجد بها مرضى ام فارغة !
// if ($result->num_rows === 0) {
//     echo "<p class='text-center text-secondary'>No patients found for this doctor.</p>"; // هيعرض هاي الرسالة لو ما لقى مرضى
// }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .welcome-message {
        background: linear-gradient(90deg, #007bff, #0056b3);
        color: white;
        border-radius: 12px;
        padding: 20px;
        text-align: center;
        font-size: 18px;
        font-weight: 500;
        margin-bottom: 30px;
    }
    .welcome-title {
        font-size: 26px; 
        font-weight: bold;
        font-style: normal;
        margin: 0;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
    }
    .welcome-subtitle {
        font-size: 14px;
        font-style: normal;
        margin: 5px 0 0;
    }
    .stars-container {
        margin: 0 10px;
    }
    .star-icon {
        color: gold; 
        font-size: 24px; 
        margin: 0 2px;
    }
        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        .buttons-container a {
            text-decoration: none;
            padding: 15px 25px;
            font-size: 15px;
            font-weight: 500;
            border-radius: 15px;
            color: white;
            transition: all 0.3s ease-in-out;
        }
        .buttons-container .add-patient {
            background-color: #007bff;
        }
        .buttons-container .add-patient:hover {
            background-color: #0056b3;
        }
        .buttons-container .logout {
            background-color: #dc3545;
        }
        .buttons-container .logout:hover {
            background-color: #c82333;
        }
        .table-container {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
            background: white;
            padding: 25px;
            margin-top: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            font-size: 13px;
        }
        .table th {
            background-color: #0069d9;
            color: white;
            font-weight: 500;
            font-style: normal;
            letter-spacing: 0.5px;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f5f9;
        }
        .action-icons a {
            margin: 0 8px;
            text-decoration: none;
        }
        .action-icons i {
            font-size: 1.3rem;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .action-icons .update-icon:hover {
            color: #007bff;
        }
        .action-icons .remove-icon:hover {
            color: #dc3545;
        }
        .action-icons .assign-drug-icon:hover {
            color: #28a745;
        }
        .page-title {
            color: #0069d9;
            font-size: 28px;
            font-family:'Poppins', Arial, sans-serif;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .page-title i {
            font-size: 30px;
            margin-right: 10px;
            color: #007bff;
        }
        .alert {
            font-size: 13px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>
<div class="container mt-5">
    <div class="welcome-message d-flex align-items-center justify-content-center">
    <div class="stars-container">
        <i class="bi bi-star-fill star-icon"></i>
        <i class="bi bi-star-fill star-icon"></i>
        <i class="bi bi-star-fill star-icon"></i>
    </div>
    <div>
        <h1 class="welcome-title">Welcome, Dr. <?php echo htmlspecialchars($name); ?>!</h1>
        <p class="welcome-subtitle">We're glad to have you here..</p>
    </div>
    <div class="stars-container">
        <i class="bi bi-star-fill star-icon"></i>
        <i class="bi bi-star-fill star-icon"></i>
        <i class="bi bi-star-fill star-icon"></i>
    </div>
</div>
    <div class="buttons-container">
        <a href="add_patient.php" class="add-patient"><i class="bi bi-person-plus-fill"></i> Add Patient</a>
        <a href="show_patients_drugs.php" class="add-patient"><i class="bi bi-capsule-pill"></i> Show Patients Drugs</a>
        <a href="logout.php" class="logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>
     <!-- عرض جدول المرضى -->
    <div class="table-container">
    <h2 class="page-title">
        <i class="bi bi-people-fill"></i> My Patients
    </h2>
    <?php if ($result->num_rows > 0) { ?><!-- التحقق إذا كان عندي مرضى -->
        <table class="table table-bordered table-hover">
            <thead>
                <tr>
                    <th>Patient Name</th>
                    <th>Email</th>
                    <th>Age</th>
                    <th>Gender</th>
                    <th>Problem</th>
                    <th>Phone Number</th>
                    <th>Entrance Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                 <!-- حلقة واايل هيضل يلف ويكرر بحيث انو يجيبلي كل المرضى يلي بضيفهم-->
            <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td><!-- عرض اسم المريض -->
                    <td><?php echo htmlspecialchars($row['email']); ?></td><!-- عرض البريد الإلكتروني -->
                    <td><?php echo htmlspecialchars($row['age']); ?></td><!-- عرض العمر -->
                    <td><?php echo htmlspecialchars($row['gender']); ?></td><!-- عرض الجنس -->
                    <td><?php echo htmlspecialchars($row['problem']); ?></td><!-- عرض المشكلة -->
                    <td><?php echo htmlspecialchars($row['phone_number']); ?></td><!-- عرض رقم الهاتف -->
                    <td><?php echo htmlspecialchars($row['entranceDate']); ?></td><!-- عرض تاريخ الدخول -->
                        <td class="action-icons">
                            <a href="update_patient.php?patient_id=<?php echo $row['id']; ?>" title="Update Patient">
                                <i class="bi bi-pencil-square update-icon text-primary"></i>
                            </a>
                            <a href="remove_patient.php?patient_id=<?php echo $row['id']; ?>" title="Remove Patient" onclick="return confirm('Are you sure you want to remove this patient?')">
                                <i class="bi bi-trash-fill remove-icon text-danger"></i>
                            </a>
                            <a href="assign_drug.php?patient_id=<?php echo $row['id']; ?>" title="Assign Drugs">
                                <i class="bi bi-capsule-pill assign-drug-icon text-success"></i>
                            </a>
                        </td>
                    </tr>
            <?php } ?>
            </tbody>
        </table>
    <?php } else { ?>
        <!-- هيظهر هادا المسج لما يكون الجدول عندي فارغ وما ضفت اي مريض لسا -->
        <p class="text-center text-secondary">No patients added until now. Please add some patients!</p>
    <?php } ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


