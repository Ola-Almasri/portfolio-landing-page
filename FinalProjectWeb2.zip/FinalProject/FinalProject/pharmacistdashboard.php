<?php
include 'db.php'; // الاتصال بقاعدة البيانات
session_start();// بدء الجلسة

// التحقق من تسجيل دخول الصيدلي
 if ($_SERVER['REQUEST_METHOD'] == 'POST') {// هون بنعمل فحص إذا الطلب من نوع POST يعني استقبلنا بيانات من الفورم
     $name = $_POST['name'];// استرجاع الاسمي
     $email = $_POST['email'];// استرجاع الايميل
     $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // تشفير الباسوررد
     $problem = $_POST['problem'];//استرجاع المشكلة
     $pharmacists_id = $_SESSION['user_id']; $problem = $_POST['problem'];// بنجيب اي دي الصيدلي المخزن في الجلية
     exit;  //انهاء السكريبت
}
     $sql_drugs = "SELECT * FROM drugs";   // بدنا نجيب قائمة الأدوية من قاعدة البيانات

     $result = $conn->query($sql_drugs);// بننفذ استعلام SQL ونحط النتيجة في متغير
     // فحص إذا كان فيه رسالة نجاح أو خطأ عند حذف الدواء
     if (isset($_GET['deleted']) && $_GET['deleted'] == 'true') { 
        echo '<div class="alert alert-success text-center">Drug deleted successfully.</div>'; 
    } elseif (isset($_GET['error'])) { 
        echo '<div class="alert alert-danger text-center">' . htmlspecialchars($_GET['error']) . '</div>'; 
    } elseif (isset($_GET['error'])) {
        echo '<div class="alert alert-danger text-center">' . htmlspecialchars($_GET['error']) . '</div>';
    } elseif (isset($_GET['success']) && $_GET['success'] == 'Drug added successfully') {
        echo '<div class="alert alert-success text-center">Drug added successfully.</div>';
    } elseif (isset($_GET['updated']) && $_GET['updated'] == 'true') {
        echo '<div class="alert alert-success text-center">Drug updated successfully.</div>';
    }
// إذا استقبلنا طلب إضافة دواء جديد
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_drug'])) {
      // نستخدم real_escape_string عشان نحمي الاستعلام من الحقن
    $name = $conn->real_escape_string($_POST['name']);
    $dosage = $conn->real_escape_string($_POST['dosage']);
    $productionDate = $conn->real_escape_string($_POST['productionDate']);
    $expiryDate = $conn->real_escape_string($_POST['expiryDate']);
    // استعلام إضافة الدواء لقاعدة البيانات
    $sql_add = "INSERT INTO drugs (name, dosage, productionDate, expiryDate) 
                VALUES ('$name', '$dosage', '$productionDate', '$expiryDate')";
    // فحص إذا تم تنفيذ الاستعلام بنجاح
    if ($conn->query($sql_add) === TRUE) {
        header("Location: pharmacistdashboard.php?success=Drug added successfully");// إعادة التوجيه مع رسالة نجاح
        exit;
    } else {
        $error = "Error: " . $conn->error;// إذا صار خطأ، نخزن رسالة الخطأ في متغير

    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pharmacist Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .welcome-message {
            background: linear-gradient(90deg, #28a745, #20c997);
            color: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            font-size: 18px;
            font-weight: 500;
            margin-bottom: 30px;
        }
        .welcome-title {
            font-size: 26px;
            font-weight: bold;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.2);
        }
        .welcome-subtitle {
            font-size: 14px;
            margin: 5px 0 0;
        }
        .stars-container {
            margin: 0 10px;
        }
        .star-icon {
            color: gold;
            font-size: 24px;
            margin: 0 2px;
        }
        .buttons-container {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 30px;
        }
        .buttons-container a {
            text-decoration: none;
            padding: 15px 25px;
            font-size: 15px;
            font-weight: 500;
            border-radius: 15px;
            color: white;
            transition: all 0.3s ease-in-out;
        }
        .buttons-container .add-drug {
            background-color: #28a745;
        }
        .buttons-container .add-drug:hover {
            background-color: #218838;
        }
        .buttons-container .logout {
            background-color: #dc3545;
        }
        .buttons-container .logout:hover {
            background-color: #c82333;
        }
        .table-container {
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 12px;
            overflow: hidden;
            background: white;
            padding: 25px;
            margin-top: 20px;
        }
        .table th, .table td {
            vertical-align: middle;
            text-align: center;
            font-size: 13px;
        }
        .table th {
            background-color: #20c997;
            color: white;
            font-weight: 500;
            font-style: normal;
            letter-spacing: 0.5px;
        }
        .table-hover tbody tr:hover {
            background-color: #f1f5f9;
        }
        .action-icons a {
            margin: 0 8px;
            text-decoration: none;
        }
        .action-icons i {
            font-size: 1.3rem;
            cursor: pointer;
            transition: all 0.2s ease-in-out;
        }
        .action-icons .edit-icon:hover {
            color: #007bff;
        }
        .action-icons .delete-icon:hover {
            color: #dc3545;
        }
        .page-title {
            color: #20c997;
            font-size: 28px;
            font-family:'Poppins', Arial, sans-serif;
            font-weight: 700;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
        }
        .page-title i {
            font-size: 30px;
            margin-right: 10px;
            color: #28a745;
        }
        .alert {
            font-size: 13px;
            margin-bottom: 15px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <!-- رسالة الترحيب -->
    <div class="welcome-message d-flex align-items-center justify-content-center">
        <div class="stars-container">
            <i class="bi bi-star-fill star-icon"></i>
            <i class="bi bi-star-fill star-icon"></i>
            <i class="bi bi-star-fill star-icon"></i>
        </div>
        <div>
            <h1 class="welcome-title">Welcome, Pharmacist!</h1>
            <p class="welcome-subtitle">Manage your inventory and assist patients effectively.</p>
        </div>
        <div class="stars-container">
            <i class="bi bi-star-fill star-icon"></i>
            <i class="bi bi-star-fill star-icon"></i>
            <i class="bi bi-star-fill star-icon"></i>
        </div>
    </div>

    <!-- الأزرار الرئيسية -->
    <div class="buttons-container">
        <a href="add_drugs.php" class="add-drug"><i class="bi bi-capsule-pill"></i> Add Drugs</a>
        <a href="logout.php" class="logout"><i class="bi bi-box-arrow-right"></i> Logout</a>
    </div>

    <!-- جدول عرض الأدوية -->
    <div class="table-container">
        <h2 class="page-title">
            <i class="bi bi-capsule-pill"></i> Available Drugs
        </h2>
        <?php if ($result->num_rows > 0): ?>
            <table class="table table-bordered table-hover">
                <thead>
                    <tr>
                        <th>Drug Name</th>
                        <th>Dosage (mg)</th>
                        <th>Production Date</th>
                        <th>Expiry Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['dosage']); ?></td>
                            <td><?php echo htmlspecialchars($row['productionDate']); ?></td>
                            <td><?php echo htmlspecialchars($row['expiryDate']); ?></td>
                            <td class="action-icons">
                            <a href="update_drug.php?id=<?php echo $row['id']; ?>" title="Edit Drug">
                            <i class="bi bi-pencil-square edit-icon text-primary"></i>
                            </a>
                            <a href="remove_drug.php?id=<?php echo $row['id']; ?>" title="Delete Drug" onclick="return confirm('Are you sure you want to delete this drug?')">
                           <i class="bi bi-trash-fill delete-icon text-danger"></i>
                           </a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p class="text-center text-secondary">No drugs added yet. Please add some drugs!</p>
        <?php endif; ?>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>






