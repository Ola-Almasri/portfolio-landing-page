<?php
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات

if (isset($_GET["patient_id"]) && is_numeric($_GET["patient_id"])) { // التحقق إذا كانت patient_id موجودة ورقمية
    $id = mysqli_real_escape_string($conn, $_GET["patient_id"]); // تنظيف القيمة لمنع هجمات SQL Injection

    $sql = "DELETE FROM patients WHERE id = $id"; // إنشاء استعلام الحذف
    $result = $conn->query($sql); // تنفيذ الاستعلام وتخزين النتيجة في result

    if ($result == true) { // التحقق إذا تم تنفيذ الاستعلام بنجاح
        header("Location:doctordashboard.php?deleted=true"); // إعادة التوجيه مع رسالة نجاح
        exit(); // إنهاء السكربت بعد إعادة التوجيه
    } else { // إذا فشل الاستعلام
        echo "Failed to delete patient: " . $conn->error; // عرض رسالة الخطأ
    }
} else {
    echo "Invalid patient ID."; // إذا كانت patient_id غير موجودة أو ليست رقمية
}
?>



