<?php
session_start(); // بدء الجلسة
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات

$errors = []; // مصفوفة فارغة لتخزين الاخطاء يلي ممكن تحصل اثناء تعبئة المستخدم لنموذج
// $success = ""; // متغير فارغ لتخزين رسالة النجاح اذا تمت عملية تحديث بيانات المرضى بنجاح

// التحقق من ان المستخدم له صلاحية الدخول سواء كان دوره دكتور او مريض
if (!isset($_SESSION['role']) || ($_SESSION['role'] !== 'doctor' && $_SESSION['role'] !== 'patient')) {
    header("Location: login.php"); // لو ما كان المستخدم مسجل او صلاحيتو مش دكتور ولا بيشنت برحعو على صفحة اللوجن
    exit();// انهاء السكريبت
}

// التحقق من وجود اي  دي البيشنت في الرابط
if (!isset($_GET['patient_id']) || empty($_GET['patient_id'])) {
    echo "Invalid request! Patient ID is missing."; // لو ما كان الاي دي موجود هتظهر رسالة الخطأ
    exit();// وهننهي السكريبت
}

$patient_id = mysqli_real_escape_string($conn, $_GET['patient_id']);//هنجيب قيمة البيشنت اي دي  المرسلة في الرابط

$sql = "SELECT * FROM patients WHERE id = '$patient_id'"; // انشاء استعلام لجلب كل الاعمدة من جدول المرضى بحيث يكون الاي دي مطابق لقيمة البيشنت اي دي
$result = $conn->query($sql); // يتم تنفيذ الاستعلام وتخزين النتيجة في كائن يمثل النتيجة التي تم استرجاعها من قاعدة البياناتSQL باستخدام اتصال قاعدة البيانات المخزن في المتغير $conn

if ($result->num_rows === 1) { // التحقق اذا كان عدد الصفوف المسترجعة من قاعدة البيانات يساوي صف واحد فقط يعني انو في تطابق وحيد مع الاي دي
    $patient = $result->fetch_assoc(); // key-valueاذا كان صف واحد فقط تقوم بجلب بيانات الصف في شكل مصفوفة
} else { // اذا لم يتم العثور على الصف
    echo "No patient found!"; // هيطبع رسالة انو البيشنت هادا مش موجود
    exit(); // وينهي السكرريبت
}

//لتحقق  إذا كان النموذج تم إرساله باستخدام الطريقة POST وأن زر التحديث تم الضغط عليه
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_patient'])) {
    $name = trim($_POST['name']); // استرجاع الاسم وازالة المسافات
    $email = trim($_POST['email']); // استرجاع الايميل وازالة المسافات
    $password = trim($_POST['password']); // استرجاع الباسووررد والزالة المسافات
    $age = $_POST['age']; // استرجاع العمر
    $gender = $_POST['gender']; // استرجاع الجنس
    $problem = trim($_POST['problem']); // استرجاع المشكلة وازالة المسافات
    $entranceDate = $_POST['entranceDate']; // استرجاع قيمة التاريخ المدخل
    $phone_number = trim($_POST['phone_number']); // استرجاع رقم الهاتف

    if (empty($name)) { // التحقق اذا كان الاسم فارغ
        $errors['name'] = "Full Name is required."; // تخزين رسالة الخطأ بالمصفوفة بانو الاسم كامل مطلوب
    }
    if (empty($email)) { // التحقق اذا كان الايميل فارغ
        $errors['email'] = "Email Address is required."; // تخزين رسالة الخطأ بالمصفوفة بانو الايميل مطلوب
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // التحقق اذا كان البريد الالكتروني صالح
        $errors['email'] = "Invalid email format."; //تخزين رسالة الخطأ بالمصفوفة بانو البريد غير صالح
    }
    if (empty($password)) { // التحقق اذا كان الباسوورد فارغ
        $password = $patient['password']; //  الاحتفاظ بكلمة المرور الحالية الموجودة بقاعدة البيانات
    } else {
        $password = password_hash($password, PASSWORD_DEFAULT); // اذا تم ادخال كلمة جديدة بنشفرها ايضا
    }
    if (empty($age) || !is_numeric($age) || $age <= 0) { // التحقق من ان العمر ليس فارغ ومش رقم واكبر او يساوي صفر
        $errors['age'] = "Valid age is required."; // تخزين رسالة الخطأ بالمصفوفة لو تحقق شرط من الشروط
    }
    if (empty($gender) || !in_array(strtolower($gender), ['male', 'female'])) { // التحقق من ان الجنس ليس فارغ  او اذا كانت القيمة المدخلة مش ذكر ولا انثى
        $errors['gender'] = "Gender must be 'male' or 'female'."; // تحزين رسالة الخطأ بالمصفوفة لو تحقق شرط من الشرطين
    }
    if (empty($problem)) { // التحقق اذا كانت المشكلة فارغة 
        $errors['problem'] = "Problem description is required."; // تخزين رسالة الخطأ بالمصفوفة بانو المشكلة مطلوبة
    }
    if (empty($entranceDate) || !strtotime($entranceDate)) { // التحقق اذا كان التاريخ فارغ او غير صالح
        $errors['entranceDate'] = "Valid entrance date is required."; // تخزين رسالة الخطأ بالمصفوفة لو تحقق شرط من الشرطين
    }
    if (empty($phone_number)) { // التحقق اذا كان رقم الهاتف  فارغ
        $errors['phone_number'] = "Phone number is required."; // تخزين رسالة الخطأ بالمصفوفة بانو المشكلة مطلوبة
    }

    // التحقق من ان مصفوفة الاخطاءفارغة يعني كل بياناتي صحيحة
    if (empty($errors)) {
       // استعلام لتحديث بيانات المرضى في قاعدة الباينات
        $update_sql = "UPDATE patients SET name = '$name', email = '$email', password = '$password', age = $age, gender = '$gender',problem = '$problem', entranceDate = '$entranceDate',phone_number = '$phone_number' WHERE id = $patient_id";
        if ($conn->query($update_sql)) { // يتم تنفيذ استعلام التحديث  اذا نجح التحديث
            // $success = "Patient updated successfully!"; //يتم تخزين رسالة النجاح في المتغير $success
            //اذا كان دور المستخدم دكتور  يتم توجيهه الى صفحة الدكتور داش بورد مع رسالة نجاح
            if ($_SESSION['role'] === 'doctor') {
                header("Location: doctordashboard.php?updated=true");
            // اذا كان دور المستخدم مريض يتم توجيهه الى صفحة البيشنت داش بورد مع رسالة نجاح
            } elseif ($_SESSION['role'] === 'patient') {
                header("Location: patientdashboard.php?updated=true");
            }
            exit(); // انهاء السكريبت
        } else { //إذا فشل استعلام التحديث يتم تخزين رسالة خطأ عامة تحتوي على تفاصيل الخطأ
            $errors['general'] = "Failed to update patient: " . $conn->error;
        }
    }
}
?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 40px;
        }
        .update-patient-container {
            background-color: #cce5ff;
            padding: 30px;
            border-radius: 20px;
            max-width: 600px;
            margin: auto;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .update-patient-header {
            font-size: 24px;
            font-weight: bold;
            color: #004085;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-label {
            font-size: 14px;
            font-weight: 500;
            color: #6c757d;
        }
        .form-control {
            border-radius: 10px;
        }
        .error-message {
            color: red;
            font-size: 12px;
            text-align: left;
        }
        .btn-update {
            background-color: #004085;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-update:hover {
            background-color:rgb(109, 158, 211);
        }
        .required-label {
          color: red;
          margin-left: 5px;
          font-size: 14px;
       }
       select.form-select {
        font-size: 14px;
        height: 35px; 
        padding: 5px;
      }
    </style>
</head>
<body>
<div class="update-patient-container">
    <h1 class="update-patient-header">Update Patient</h1>
    <form action="update_patient.php?patient_id=<?php echo htmlspecialchars($patient_id); ?>" method="POST">
    <!--التحقق إذا كانت هناك رسالة نجاح أو خطأ عام ويتم عرضها داخل عنصر <div>-->
        <?php if (!empty($success)) { ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php } ?>
        <?php if (!empty($errors['general'])) { ?>
            <div class="alert alert-danger"><?php echo $errors['general']; ?></div>
        <?php } ?>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Full Name <span class="required-label">*</span></label>
                <input type="text" name="name" class="form-control" 
                    value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : htmlspecialchars($patient['name']); ?>">
                <?php if (isset($errors['name'])) { ?>
                    <div class="error-message"><?php echo $errors['name']; ?></div>
                <?php } ?>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Email Address <span class="required-label">*</span></label>
                <input type="email" name="email" class="form-control" 
                    value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : htmlspecialchars($patient['email']); ?>">
                <?php if (isset($errors['email'])) { ?>
                    <div class="error-message"><?php echo $errors['email']; ?></div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" 
                    value="<?php echo htmlspecialchars($patient['password']); ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Age <span class="required-label">*</span></label>
                <input type="number" name="age" class="form-control" 
                    value="<?php echo isset($_POST['age']) ? htmlspecialchars($_POST['age']) : htmlspecialchars($patient['age']); ?>">
                <?php if (isset($errors['age'])) { ?>
                    <div class="error-message"><?php echo $errors['age']; ?></div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Gender <span class="required-label">*</span></label>
                <select name="gender" id="gender" class="form-select">
                    <option value="" <?php echo (!isset($patient['gender']) || empty($patient['gender'])) ? 'selected' : ''; ?>>Select Gender</option>
                    <option value="male" <?php echo ($patient['gender'] === 'male') ? 'selected' : ''; ?>>Male</option>
                    <option value="female" <?php echo ($patient['gender'] === 'female') ? 'selected' : ''; ?>>Female</option>
                </select>
                <?php if (isset($errors['gender'])) { ?>
                    <div class="error-message"><?php echo $errors['gender']; ?></div>
                <?php } ?>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Phone Number <span class="required-label">*</span></label>
                <input type="text" name="phone_number" id="phone_number" class="form-control" 
                    value="<?php echo isset($_POST['phone_number']) ? htmlspecialchars($_POST['phone_number']) : htmlspecialchars($patient['phone_number']); ?>">
                <?php if (isset($errors['phone_number'])) { ?>
                    <div class="error-message"><?php echo $errors['phone_number']; ?></div>
                <?php } ?>
            </div>
        </div>
        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Entrance Date <span class="required-label">*</span></label>
                <input type="date" name="entranceDate" id="entranceDate" class="form-control" 
                    value="<?php echo isset($_POST['entranceDate']) ? htmlspecialchars($_POST['entranceDate']) : htmlspecialchars($patient['entranceDate']); ?>">
                <?php if (isset($errors['entranceDate'])) { ?>
                    <div class="error-message"><?php echo $errors['entranceDate']; ?></div>
                <?php } ?>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Problem Description <span class="required-label">*</span></label>
                <textarea name="problem" id="problem" class="form-control"><?php echo isset($_POST['problem']) ? htmlspecialchars($_POST['problem']) : htmlspecialchars($patient['problem']); ?></textarea>
                <?php if (isset($errors['problem'])) { ?>
                    <div class="error-message"><?php echo $errors['problem']; ?></div>
                <?php } ?>
            </div>
        </div>
        <div class="text-center">
            <button type="submit" name="update_patient" class="btn btn-update">Update</button>
        </div>
    </form>
</div>
</body>
</html>


