<?php
// تعريف معلومات الاتصال بقاعدة البيانات
$host = "localhost";// اسم الخادم 
$user = "root";//اسم المستخدم
$pass = "";//كلمة المرور
$db = "Hospital";// اسم قاعدة البيانات
$conn = new mysqli($host, $user, $pass);// انشاء الاتصال بالخادم
//  if ($conn->connect_error) {
//      echo("فشل الاتصال بالخادم: " . $conn->connect_error);
//  }
// $sql = "CREATE DATABASE $db";// إنشاء قاعدة البيانات باستخدام استعلام SQL
// //  if ($conn->query($sql) === TRUE) {
// //      echo "تم إنشاء قاعدة البيانات بنجاح.<br>";
// //  } else {
// //      echo("خطأ في إنشاء قاعدة البيانات: " . $conn->error);
// //  }
$conn->select_db($db);//حددنا قاعدة البيانات الى بدنا نستخدمها
// تعريف الاستعلامات لإنشاء الجداول داخل قاعدة البيانات
$tables = [
    "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone_number VARCHAR(15),
        role ENUM('doctor', 'pharmacist' ,'patient') NOT NULL
    )",
    "CREATE TABLE IF NOT EXISTS doctors (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone_number VARCHAR(15)
    )",
    "CREATE TABLE IF NOT EXISTS patients (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        age INT,
        gender VARCHAR(10),
        problem TEXT,
        entranceDate DATE,
        phone_number VARCHAR(15)
    )",
    "CREATE TABLE IF NOT EXISTS pharmacists (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        phone_number VARCHAR(15)
    )",
    "CREATE TABLE IF NOT EXISTS drugs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        dosage DOUBLE NOT NULL,
        productionDate DATE NOT NULL,
        expiryDate DATE NOT NULL
    )",
    "CREATE TABLE IF NOT EXISTS patientdoctor (
        pat_id INT NOT NULL,
        doc_id INT NOT NULL,
        PRIMARY KEY (pat_id, doc_id),
        FOREIGN KEY (pat_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY (doc_id) REFERENCES doctors(id) ON DELETE CASCADE
    )",
    "CREATE TABLE IF NOT EXISTS patientdrug (
        pat_id INT NOT NULL,
        drug_id INT NOT NULL,
        PRIMARY KEY (pat_id, drug_id),
        FOREIGN KEY (pat_id) REFERENCES patients(id) ON DELETE CASCADE,
        FOREIGN KEY (drug_id) REFERENCES drugs(id) ON DELETE CASCADE
    )"
];
// foreach ($tables as $sql) {
//      if ($conn->query($sql) === TRUE) {
//          echo "تم إنشاء الجدول بنجاح.<br>";
//      } else {
//          echo "خطأ في إنشاء الجدول: " . $conn->error . "<br>";
//      }
//  }
// //  $conn->close();// إغلاق الاتصال بالخادم
?>
