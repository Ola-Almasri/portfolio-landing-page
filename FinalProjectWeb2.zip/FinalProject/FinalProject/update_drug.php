<?php
include 'db.php'; // الاتصال بقاعدة البيانات
session_start();// بدء جلسة جديدة أو متابعة الجلسة الحالية

// بنفحص إذا المستخدم اللي داخل هو صيدلي
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'pharmacist') {
     // إذا مش صيدلي، بنرجعه على صفحة تسجيل الدخول
    header("Location: login.php");
    exit(); // انهاء السكربت
}

// بنجيب اي دي الدواء الى بدنا نعدّله من الرابط
$drug_id = $_GET['id']; 
//  استعلام عشان نجيب بيانات الدواء من قاعدة البيانات
$sql = "SELECT * FROM drugs WHERE id = ?";
$stmt = $conn->prepare($sql);// تجهيز الاستعلام
$stmt->bind_param("i", $drug_id); // ربط الاي دي مع الاستعلام (نوعه عدد صحيح)
$stmt->execute();// تشغيل الاستعلام
$result = $stmt->get_result();// تخزين النتيجة

// بنفحص إذا البيانات موجودة لدواء واحد
if ($result->num_rows === 1) {
    $drug = $result->fetch_assoc();// تخزين بيانات الدواء في متغير
} else { // إذا مفيش دواء بالمعلومات، بنعرض رسالة
    echo "No drug found!";
    exit();
}

// إذا المستخدم ضغط على زر التحديث (طلب POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // بنجيب البيانات الى المستخدم عدّلها بالفورم
    $name = $_POST['name'];// اسم الدواء
    $dosage = $_POST['dosage']; // الجرعة
    $productionDate = $_POST['productionDate'];// تاريخ الإنتاج
    $expiryDate = $_POST['expiryDate'];// تاريخ الانتهاء

      // مصفوفة لتخزين الأخطاء لو فيه مشاكل بالإدخال
    $errors = [];
    if (empty($name)) {// بدي افحص لو كان اسم الدواء فارغ
        $errors['name'] = "Drug name is required.";// هتتخزن رسالة الخطأ بالمصفوفة  بانو اسم الدواء مطلوب
    }
    if (empty($dosage) || !is_numeric($dosage) || $dosage <= 0) {// إذا الجرعة فارغة او مش رقم أو <= 0
        $errors['dosage'] = "Valid dosage is required.";//هتتخزن رسالة الخطأ بالمصفوفة لو تحققت احدى الشروط
    }
    if (empty($productionDate) || !strtotime($productionDate)) { //بدي افحص  إذا تاريخ الإنتاج فاضي أو مش تاريخ صحيح
        $errors['productionDate'] = "Valid production date is required.";// هتتخزن رسالة الخطأ بالمصفوفة بانو مطلوب تاريخ صحيح
    }
    if (empty($expiryDate) || !strtotime($expiryDate)) {//بدي افحص  إذا تاريخ الانتهاء فاضي أو مش تاريخ صحيح
        $errors['expiryDate'] = "Valid expiry date is required.";// هتتخزن رسالة الخطأ بالمصفوفة بانو مطلوب تاريخ صحيح
    }
    if (!isset($errors['expiryDate']) && strtotime($expiryDate) <= strtotime($productionDate)) {// إذا تاريخ الانتهاء أقل أو يساوي تاريخ الإنتاج
        $errors['expiryDate'] = "Expiry date must be after production date.";
    }
    // إذا ما فيه أخطاء، بنعمل تحديث للدواء
    if (empty($errors)) {
        // استعلام SQL للتحديث
        $update_sql = "UPDATE drugs SET name = ?, dosage = ?, productionDate = ?, expiryDate = ? WHERE id = ?";
        $stmt = $conn->prepare($update_sql);// تجهيز الاستعلام
        $stmt->bind_param("sissi", $name, $dosage, $productionDate, $expiryDate, $drug_id);

        if ($stmt->execute()) {// تشغيل استعلام التحديث
            // إذا نجح التحديث، بنرجّع المستخدم لصفحة الصيدلي مع رسالة نجاح
            header("Location: pharmacistdashboard.php?updated=true");
            exit();
        } else {// إذا التحديث فشل، بنحط رسالة خطأ عامة
            $errors['general'] = "Failed to update drug: " . $conn->error;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Drug</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .update-drug-container {
            background-color: rgb(32, 201, 151);
            padding: 30px;
            border-radius: 20px;
            width: 400px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .update-drug-header {
            font-size: 24px;
            font-weight: bold;
            color: white;
            margin-bottom: 20px;
        }
        .form-label {
            font-size: 15px;
            font-weight: 500;
            color: rgb(237, 241, 245);
            text-align: left;
            display: block; 
        }
        .required {
          color: red;
         font-size: 16px;
         font-weight: bold;
         }
        .error-message {
            color: #dc3545;
            font-size: 13px;
            text-align: left;
            margin-top:5px;
        }
        .form-control {
            border-radius: 10px;
        }
        .btn-update {
            background-color: #d63031;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-update:hover {
            background-color: #c0392b;
        }
    </style>
</head>
<body>
<div class="update-drug-container">
    <h1 class="update-drug-header">Update Drug</h1>

    <form action="update_drug.php?id=<?php echo $drug_id; ?>" method="POST">
        <div class="mb-3">
            <label class="form-label">
                <i class="bi bi-capsule"></i> Name <span class="required">*</span>
            </label>
            <input type="text" name="name" id="name" class="form-control" 
                value="<?php echo isset($_POST['name']) ? htmlspecialchars($_POST['name']) : htmlspecialchars($drug['name']); ?>">
            <?php if (isset($errors['name'])) { ?>
                <div class="error-message"><?php echo $errors['name']; ?></div>
            <?php } ?>
        </div>

        <div class="mb-3">
            <label class="form-label">
                <i class="bi bi-eyedropper"></i> Dosage <span class="required">*</span>
            </label>
            <input type="number" name="dosage" id="dosage" class="form-control" 
                value="<?php echo isset($_POST['dosage']) ? htmlspecialchars($_POST['dosage']) : htmlspecialchars($drug['dosage']); ?>">
            <?php if (isset($errors['dosage'])) { ?>
                <div class="error-message"><?php echo $errors['dosage']; ?></div>
            <?php } ?>
        </div>

        <div class="mb-3">
            <label class="form-label">
                <i class="bi bi-calendar-check"></i> Production Date <span class="required">*</span>
            </label>
            <input type="date" name="productionDate" id="productionDate" class="form-control" 
                value="<?php echo isset($_POST['productionDate']) ? htmlspecialchars($_POST['productionDate']) : htmlspecialchars($drug['productionDate']); ?>">
            <?php if (isset($errors['productionDate'])) { ?>
                <div class="error-message"><?php echo $errors['productionDate']; ?></div>
            <?php } ?>
        </div>

        <div class="mb-3">
            <label class="form-label">
                <i class="bi bi-calendar-x"></i> Expiry Date <span class="required">*</span>
            </label>
            <input type="date" name="expiryDate" id="expiryDate" class="form-control" 
                value="<?php echo isset($_POST['expiryDate']) ? htmlspecialchars($_POST['expiryDate']) : htmlspecialchars($drug['expiryDate']); ?>">
            <?php if (isset($errors['expiryDate'])) { ?>
                <div class="error-message"><?php echo $errors['expiryDate']; ?></div>
            <?php } ?>
        </div>

        <button type="submit" class="btn btn-update">Update</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
