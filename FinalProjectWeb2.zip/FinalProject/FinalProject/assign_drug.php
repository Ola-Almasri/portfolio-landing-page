<?php
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات
session_start(); //بدء الجلسة

$patient_id = intval($_GET['patient_id']); // بدي اجيب اي دي المريض من الرابط باستخدام $_GET['patient_id'] وتحويله إلى رقم صحيح باستخدام intval

// استعلام SQL عشان يجيب الأدوية من جدول drugs
$query = "SELECT id, name, dosage FROM drugs";
$result = $conn->query($query); // تنفيذ الاستعلام على قاعدة البيانات وتخزين النتيجة في المتغير $result

if ($result) { //إذا كان الاستعلام ناجح بتم تحويل ال result إلى مصفوفة من الأدوية
    $drugs = $result->fetch_all(MYSQLI_ASSOC);
} else {
    $drugs = []; // إذا فشل الاستعلام بتم تعيين المتغير $drugs إلى مصفوفة فارغة
}

// في حالة كانت الطريقة GET و action=getDrugs بتم تنفيذ الاستعلام عشان نجيب الأدوية
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getDrugs') {
    $query = "SELECT id, name, dosage FROM drugs";
    $result = $conn->query($query); // تنفيذ الاستعلام 

    if ($result) { // التحقق إذا كانت نتيجة الاستعلام ناجحة
      //
//تحول نتايج الاستعلام إلى مصفوفة بتحتوي على بيانات الأدوية حيث يتم الوصول إلى القيم باستخدام أسماء الأعمدة والنتيجة تُخزن في المتغير $drugs
        $drugs = $result->fetch_all(MYSQLI_ASSOC);
        echo json_encode($drugs); // تحويل الأدوية إلى تنسيق JSON لإرسالها إلى العميل
    } else {
        echo json_encode(['error' => 'Failed to fetch drugs']);//في حالة حدوث خطأ بتم إرسال رسالة error
    }
    exit();
}
// جلب الأدوية المرتبطة بالمريض
// جلب الأدوية من جدول drugs لعرضها في القائمة المنسدلة
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getDrugs') {
  $query = "SELECT id, name, dosage FROM drugs";
  $result = $conn->query($query); // تنفيذ الاستعلام

  if ($result) {
      $drugs = $result->fetch_all(MYSQLI_ASSOC);
      echo json_encode($drugs); // إرسال الأدوية كـ JSON
  } else {
      echo json_encode(['error' => 'Failed to fetch drugs']);
  }
  exit();
}
// التحقق إذا كان الطلب من نوع GET وإذا كان action يساوي getAssignedDrugs
if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['action']) && $_GET['action'] === 'getAssignedDrugs') {
  //الاستعلام بيعمل ربط بين جدول patientdrug اللي بيخزن الأدوية اللي مرتبطة بكل مريض وجدول drugs اللي فيه تفاصيل الأدوية بيستخدم drug_id عشان يربط الدواء بالمريض وبيقارن pat_id بـ $patient_id اللي جاي من الرابط علشان يجيب الأدوية الى بتخص المريض هادا
  $query = "SELECT drugs.id, drugs.name, drugs.dosage 
            FROM patientdrug 
            JOIN drugs ON patientdrug.drug_id = drugs.id 
            WHERE patientdrug.pat_id = '$patient_id'";
  $result = $conn->query($query);
//إذا كانت النتيجة صح الكود بيجيب كل الأدوية المخصصة للمريض ويحطها في $assigned_drugs وبعدين بيحولها لـ JSON وببعتها للعميل لو في خطأ ببعت رسالة خطأ بـ JSON بتقول "فشل في جلب الأدوية المخصصة"
  if ($result) {
      $assigned_drugs = $result->fetch_all(MYSQLI_ASSOC);
      echo json_encode($assigned_drugs);
  } else {
      echo json_encode(['error' => 'Failed to fetch assigned drugs']);
  }
  exit();// انهاء السكريبت
}
//  التحقق إذا كان الطلب من نوع POST وإذا كان action يساوي assign
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'assign') {
  $drug_id = intval($_POST['drug_id']); // بنجيب drug_id من $_POST وتحويله إلى رقم صحيح باستخدام intval()

  // إذا كانت drug_id أو patient_id فارغة أو غير صحيحة بتم إرسال رسالة خطأ باستخدام json_encode() مع إيقاف التنفيذ باستخدام exit()
  if (!$drug_id || !$patient_id) {
      echo json_encode(['error' => 'Invalid data provided']);
      exit();
  }

  // بتم تنفيذ استعلام SELECT للتحقق إذا كان drug_id قد تم ربطه بالفعل بالمريض باستخدام patient_id إذا كانت في  علاقة موجودة بين المريض والدواء فهادا بيعني انو الدواء قد تم تخصيصه بالفعل لهادا المريض
  $check_query = "SELECT * FROM patientdrug WHERE pat_id = '$patient_id' AND drug_id = '$drug_id'";
  $check_result = $conn->query($check_query);
//إذا كانت النتيجة تحتوي على صف واحد أو اكتر فهادا بيعني انو الدواء قد تم تخصيصه بالفعل للمريض وبالتالي بتم ارسال رسالة خطأ وايقاف التنفيذ
  if ($check_result->num_rows > 0) {
      echo json_encode(['error' => 'This drug is already assigned to the patient.']);
      exit();
  }
  //إضافة العلاقة بين المريض والدواءإذا لم يكن الدواء مخصصًا للمريض بالفعل بتم إضافة العلاقة باستخدام INSERT INTO
  $query = "INSERT INTO patientdrug (pat_id, drug_id) VALUES ('$patient_id', '$drug_id')";
  if ($conn->query($query)) { //اذا تم تنفيذ الاستعلام بنجاح يتم إرسال رسالة نجاح إلى العميل وإذا فشل الاستعلام يتم إرسال رسالة خطأ
      echo json_encode(['success' => 'Drug assigned successfully']);
  } else {
      echo json_encode(['error' => 'Failed to assign drug']);
  }
  exit();
}
//التحقق إذا كان الطلب من نوع POST وإذا كان action يساوي remove
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'remove') {
  $drug_id = intval($_POST['drug_id']);//بنجيبdrug_id من $_POST وتحويله إلى رقم صحيح باستخدام intval()
//يتم تنفيذ استعلام DELETE لحذف العلاقة بين المريض والدواء باستخدام patient_id و drug_id
  $query = "DELETE FROM patientdrug WHERE pat_id = '$patient_id' AND drug_id = '$drug_id'";
  //إذا تم تنفيذ الاستعلام بنجاح بتم إرسال رسالة نجاح إلى العميل وإذا فشل الاستعلام بتم إرسال رسالة خطأ
  if ($conn->query($query)) {
      echo json_encode(['success' => 'Drug removed successfully']);
  } else {
      echo json_encode(['error' => 'Failed to remove drug']);
  }
  exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Assign Drugs</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
    }

    .container {
      max-width: 900px;
      margin: 50px auto;
      background: #ffffff;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      padding: 30px;
    }

    h1 {
      font-size: 28px;
      font-weight: 600;
      color: #3a3a3a;
      text-align: center;
      margin-bottom: 20px;
      position: relative;
    }

    h1::after {
      content: "";
      display: block;
      width: 50px;
      height: 3px;
      background: #007bff;
      margin: 10px auto 0;
      border-radius: 2px;
    }

    .select-drug {
      display: flex;
      gap: 15px;
      margin-bottom: 20px;
    }

    .select-drug select {
      flex: 1;
      padding: 10px;
      border-radius: 10px;
      border: 1px solid #ddd;
      font-size: 14px;
      background: #f9f9f9;
      transition: border-color 0.3s;
    }

    .select-drug select:focus {
      border-color: #007bff;
      background: #ffffff;
    }

    .btn-primary {
      padding: 10px 20px;
      font-size: 14px;
      font-weight: 600;
      color: #ffffff;
      background-color: #007bff;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      transition: all 0.3s ease;
    }

    .btn-primary:hover {
      background-color: #0056b3;
    }

    .table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    .table th {
      background: linear-gradient(90deg, #007bff, #0056b3);
      color: #ffffff;
      font-weight: 500;
      padding: 12px;
      border: none;
      box-shadow: inset 0 -3px 0 rgba(0, 0, 0, 0.2), 0 3px 6px rgba(0, 0, 0, 0.1);
      text-align: center;
      font-size: 12px;
    }

    .table td {
      padding: 12px;
      text-align: left;
      border-bottom: 1px solid #eeeeee;
      text-align: center; 
      font-size: 12px; 
    }

    .btn-remove {
      padding: 5px 15px;
      font-size: 12px;
      color: #ffffff;
      background-color: #e74c3c;
      border: none;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }

    .btn-remove:hover {
      background-color: #c0392b;
    }

    .back-btn {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      font-size: 14px;
      font-weight: 500;
      color: #555555;
      background-color: #f0f0f0;
      border: none;
      border-radius: 10px;
      text-decoration: none;
      text-align: center;
      transition: background-color 0.3s ease;
    }

    .back-btn:hover {
      background-color:rgb(155, 163, 172);
    }
     #empty-row td {
      text-align: center;
      color: gray; 
      font-size: 12px; 
      font-weight: 300; 
      letter-spacing: 0.5px; 
    }
  </style>
</head>
<body>
<div class="container">
  <h1><i class="fas fa-pills"></i> Assign Drugs</h1>
<!-- Drug Selection -->
<div class="select-drug">
  <select name="drug" id="drug">
    <option value="" disabled selected>Select Drug</option>
    <?php foreach ($drugs as $drug) { ?>
      <option value="<?php echo htmlspecialchars($drug['id']); ?>" data-dosage="<?php echo htmlspecialchars($drug['dosage']); ?>">
        <?php echo htmlspecialchars($drug['name']); ?>
      </option>
    <?php } ?>
  </select>
  <button class="btn-primary" id="assign-btn"><i class="fas fa-plus-circle"></i> Assign</button>
</div>
  <!-- Table -->
  <table class="table">
    <thead>
      <tr>
        <th><i class="fas fa-capsules"></i> Drug Name</th>
        <th><i class="fas fa-prescription-bottle"></i> Dosage</th>
        <th><i class="fas fa-tools"></i> Action</th>
      </tr>
    </thead>
      <!--<tbody> يتم تحديثه ديناميكيًا من خلال JavaScript لعرض الأدوية المخصصة-->
    <tbody id="drug-table-body">
      <tr id="empty-row"> <!--صف فارغ افتراضي يظهر إذا لم تكن هناك أدوية مضافة-->
        <td colspan="3">No drugs added yet. Please add some drugs.</td>
      </tr>
    </tbody>
  </table>
  <!-- Back Button -->
  <a href="doctordashboard.php" class="back-btn">
    <i class="fas fa-arrow-left"></i> Back to Dashboard
  </a>
</div>
<script>
  const patientId = <?php echo json_encode($patient_id); ?>;// البيشنت اي دي بتم تمريره من ال php
  const tableBody = document.getElementById('drug-table-body'); //العنصر الذي يتم تحديثه لعرض الأدوية المخصصة
  const assignBtn = document.getElementById('assign-btn'); // الزر الخاص باضافة الادوية
  const drugSelect = document.getElementById('drug');

  function loadAssignedDrugs() { // تحميل الادوية المخصصة للمريض
    //fetch ببعت طلب لملف assign_drug.php عشان يجيب الأدوية المخصصة للمريض باستخدام patient_id ونوع العملية
    fetch(`assign_drug.php?patient_id=${patientId}&action=getAssignedDrugs`) 
    //response هي استجابة الخادم و response.json() بيحول البيانات الي اجت من الخادم لصيغة JSON عشان نقدر نستخدمها في الكود
      .then(response => response.json())
      .then(data => { //الدالة هاي بتشتغل بعد ما تجيب البيانات من fetch، و data هي البيانات اللي رجعت من السيرفر زي الأدوية المخصصة
        tableBody.innerHTML = ''; // بفضي الجدول من البيانات القديمة عشان اضيف بيانات جديدة
        if (data.length > 0) { //التحقق اذا كانت القائمة بتحتوي على ادوية
          data.forEach(drug => { // لو كان في ادوية تكرار كل دواء داخل القائمة
            const row = document.createElement('tr'); //انشاء صف جديد في الجدول
           // الكود هادا بضيف صف جديد في الجدول فيه اسم الدواءو جرعته وزرار لحذفه عند الضغط عليهم
            row.innerHTML = ` 
              <td>${drug.name}</td>
              <td>${drug.dosage}</td>
              <td>
                <button class="btn-remove" onclick="removeDrug(${drug.id})">
                  <i class="fas fa-trash-alt"></i> Remove
                </button>
              </td>
            `;
            tableBody.appendChild(row); // الصف الجديد يلي نعمل هيظهر بالجدول في الصفحة
          });
        } else { // لو ما في ادوية يعني البيانات كانت فارغة
          tableBody.innerHTML = '<tr><td colspan="3">No drugs assigned yet.</td></tr>'; // بضيف صف في الجدول مع مسج انو لسا ما في ادوية
        }
      });
  }
  assignBtn.addEventListener('click', () => { // بضيف مستمع لزر ال assignBtnعشان لما المستخدم يضغط عليه  يتم تنفيذ يلي جواه 
    const drugId = drugSelect.value;//بيأخذ قيمة الدواء اللي تم اختياره من القائمة  drugSelect ويخزنها في المتغير drugId
    if (drugId) {//بشوف إذا كان المستخدم اختار دواء من القائمة لو القيمة موجودة هيتنفذ الكود الى داخل الـ if
      fetch(`assign_drug.php?patient_id=${patientId}`, {// fetch: بعت طلب POST للملف assign_drug.php
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, // بحدد نوع البيانات المرسلة
        body: `action=assign&drug_id=${drugId}`//ببعت البيانات الى بتحدد نوع العملية (إضافة دواء) و اي دي الدواء اللي تم اختياره
      })
      .then(response => response.json())//بيحول الاستجابة من الخادم إلى JSON علشان نقدر نستخدمها في الكود
      .then(data => {//إذا كانت الاستجابة تحتوي على success بيتم استدعاء loadAssignedDrugs() لعرض الأدوية المحدثة
        if (data.success) {
          loadAssignedDrugs();
          //إذا كانت الاستجابة تحتوي على ايرور بيظهر alert للخطأ اللي رجع من السيرفر
        } else if (data.error) {
          alert(data.error);
        }
      })
      //لو حصل خطأ في عملية fetch أو في تنفيذ أي جزء من الكود بيتم تسجيله في الـ console
      .catch(err => console.error('Error:', err));
    } else {
      alert('Please select a drug first!');//لو ما تم اختيار دواء بيظهر تنبيه alert للمستخدم يطلب منه اختيار دواء أولا
    }
  });

  function removeDrug(drugId) { //drugId المراد حذفه وبتحذفه الدالة هاي لازالة الدواء بتاخد ال
    fetch(`assign_drug.php?patient_id=${patientId}`, { //بيتم إرسال طلب POST للملف assign_drug.php
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },//تحديد نوع البيانات المرسلة
      body: `action=remove&drug_id=${drugId}` //إرسال العملية المطلوبة (الحذف) و اي دي الدواء الذي سيتم إزالته
    })
    .then(response => response.json())//بيحول الاستجابة القادمة من الخادم إلى JSON حتى نقدر نستخدم البيانات بسهولة
    .then(data => {
      if (data.success) { //لو كانت الاستجابة تحتوي على success هيتم استدعاء loadAssignedDrugs() لتحميل الأدوية المحدثة بعد الحذف
        loadAssignedDrugs();
      } else if (data.error) {//لو كانت الاستجابة تحتوي على ايرور هيتم عرض رسالة alert تحتوي على الخطأ
        alert(data.error);
      }
    });
  }
  loadAssignedDrugs();//بعد حذف الدواء بتم استدعاء هاي الدالة لتحميل الأدوية المخصصة المحدثة من الخادم وعرضها في الجدول
</script>
</body>
</html>