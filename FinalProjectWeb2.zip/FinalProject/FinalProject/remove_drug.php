<?php
include 'db.php'; // الاتصال بقاعدة البيانات
session_start();//بدء الجلسة

// التحقق من وجود اي دي الدواء في الرابط
if (isset($_GET["id"])) {
    $drug_id = $_GET["id"]; // بنخزن الاي دي الى جاي من الرابط في متغير $drug_id

    // حذف الدواء من قاعدة البيانات
    $sql = "DELETE FROM drugs WHERE id = ?";// بنكتب استعلام SQL عشان نحذف الدواء بناءً على الاي دي
    $stmt = $conn->prepare($sql);   // بنجهز الاستعلام باستخدام prepare عشان نحميه من الثغرات (مثل حقن SQL)
    $stmt->bind_param("i", $drug_id); // بنربط المعرّف مع الاستعلام (نوع المتغير هون عدد صحيح "i")

    // بنحاول ننفذ الاستعلام
    if ($stmt->execute()) { // إذا الحذف نجح، بنرجّع المستخدم لصفحة الصيدلي مع رسالة نجاح
        // نجاح الحذف
        header("Location: pharmacistdashboard.php?deleted=true");
        exit();// انهاء السكريبت
    } else {// إذا صار خطأ أثناء الحذف، بنرجّع المستخدم لصفحة الصيدلي مع رسالة خطأ
        header("Location: pharmacistdashboard.php?error=Failed to delete the drug");
        exit();// انهاء السكربت
    }
} else {
    // إذا الاي دي (id) ما كان موجود بالرابط
    // بنرجّع المستخدم مع رسالة إنه الطلب مش صحيح
    header("Location: pharmacistdashboard.php?error=Invalid request");
    exit();// انهء السكربت
}
?>

