<?php
session_start(); // بدء الجلسة
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات

$errors = []; // مصفوفة لتخزين رسائل الخطأ

// التحقق من الحقول وعرض رسايل الخطأ لو كانوا فارغين
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']); // استرجاع البريد الإلكتروني
    $password = trim($_POST['password']); // استرجاع كلمة المرور

    if (empty($email)) { // لو كان الايميل فارغ
        $errors['email'] = "Email is required.";// هتتخزن رسالة الخطأ بالمصفوفة بانو الايميل مطلوب
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) { // بدي اتحقق هل الايميل يلي دخلو المستخدم صالح
        $errors['email'] = "Invalid email format."; // ولو مش صالح هتتخزن رسالة الخطأ بالمصفوفة
    }
    if (empty($password)) { // لو كانت كلمة السر فارغة
        $errors['password'] = "Password is required.";
    }

    //لو مصفوفة الخطأ كانت فارغة  يعني ما فيها اخطاء
    if (empty($errors)) {
        // التحقق من وجود البريد الإلكتروني في جدول `users` في حالة كان المستخدم دكتور أو صيدلي
        $sql_users = "SELECT * FROM users WHERE email = '$email'"; // البحث عن المستخدم في جدول `users`
        $result_users = mysqli_query($conn, $sql_users); // تنفيذ الاستعلام

        if ($result_users && $result_users->num_rows > 0) {
            $user = $result_users->fetch_assoc();

            // التحقق من كلمة المرور
            if (password_verify($password, $user['password'])) { 
                // تخزين بيانات المستخدم في الجلسة
                $_SESSION['user_id'] = $user['id'];// تخزين اي دي اليوزر
                $_SESSION['name'] = $user['name']; // تخزين اسم اليوزر
                $_SESSION['role'] = $user['role']; // تخزين دور اليوزر

                //هينتقل المستخدم لصفحة اخرى بناء على دوه
                if ($user['role'] === 'doctor') { // لو كان دكتور
                    setcookie("userEmail", $email, time() + 31536000, "/"); // تخزين الكوكي
                    header("Location: doctordashboard.php");
                    exit();
                } elseif ($user['role'] === 'pharmacist') { // لو كان صيدلي
                    setcookie("userEmail", $email, time() + 31536000, "/"); // تخزين الكوكي
                    header("Location: pharmacistdashboard.php");
                    exit();
                }
                if ($user['role'] === 'patient') { // لو كان مريض
                    // التحقق من البريد الإلكتروني في جدول `patients`
                    $sql_patient = "SELECT * FROM patients WHERE email = '$email'"; // التحقق في جدول `patients`
                    $result_patient = mysqli_query($conn, $sql_patient); // تنفيذ الاستعلام

                    if ($result_patient && $result_patient->num_rows > 0) {
                        $patient = $result_patient->fetch_assoc();

                        // التحقق من كلمة المرور الخاصة بالمريض
                        if (password_verify($password, $patient['password'])) {
                            // تخزين بيانات المريض في الجلسة
                            $_SESSION['patient_id'] = $patient['id']; //تخزين اي دي المؤيض
                            $_SESSION['gender'] = $patient['gender']; // تخزين الجنس
                            $_SESSION['age'] = $patient['age']; // تخزين العمر
                            setcookie("userEmail", $email, time() + 31536000, "/"); // تخزين الكوكي
                            header("Location: patientdashboard.php");
                            exit();
                        } else {
                            $errors['login'] = "Invalid email or password.";
                        }
                    } else {
                        $errors['login'] = "User not found in patients table.";
                    }
                }
            } else {
                $errors['login'] = "Invalid email or password.";
            }
        } else {
            $errors['login'] = "User not found in users table.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: #f0f4f8;
        }
        .login-card {
            max-width: 900px;
            width: 100%;
            display: flex;
            background: white;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
            border-radius: 15px;
            overflow: hidden;
        }
        .login-image {
            flex: 1;
            background: url('./-11 05.12.04_489bb804.jpg') no-repeat center;
            background-size: 420px;
            background-position: right -50px center;
        }
        .login-form {
            flex: 1;
            padding: 80px 70px;
            height: 500px;
            justify-content: space-between;
        }
        .login-header {
            font-size: 22px;
            font-weight: bold;
            color: #d63031;
            text-align: center;
            text-shadow: 1px 1px 5px rgba(0, 0, 0, 0.2);
            margin-bottom: 30px;
            font-family: 'Poppins', Arial, sans-serif;
        }
        .btn-primary {
            background-color: #007bff;
            border: none;
            font-size: 16px;
            border-radius: 15px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        .register-link {
            color: #007bff;
            text-decoration: none;
        }
        .register-link:hover {
            text-decoration: underline;
        }
        .form-label {
            font-family: 'Arial', sans-serif;
            font-size: 14px;
            font-weight: 450;
            color: #333;
            margin-bottom: 10px;
        }
        .error-message {
            color: #dc3545;
            font-size: 12px;
            margin-top: 5px;
        }
        .text-center span, .text-center a {
            font-family: 'Arial', sans-serif;
            font-size: 14px;
            
         }
         .register-link {
         font-size: 16px; 
         font-weight: bold; 
        }
    </style>
</head>
<body>
<div class="login-container">
        <div class="login-card">
        <div class="login-image"></div>
        <div class="login-form">
            <h2 class="login-header">Welcome Back Dear!</h2>
           <!-- رسالة خطأ عامة -->
           <?php
            if (!empty($errors['login'])) {
             echo '<div class="alert alert-danger">' . htmlspecialchars($errors['login']) . '</div>';}?>
           <form action="login.php" method="POST">
           <!-- Email Address -->
       <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="Enter your email"
               value="<?php echo isset($email) ? htmlspecialchars($email) : ''; ?>">
              <?php
              if (!empty($errors['email'])) {
                echo '<div class="error-message">' . htmlspecialchars($errors['email']) . '</div>';}?>
       </div>
         <!-- Password -->
      <div class="mb-3">
       <label class="form-label">Password</label>
       <input type="password" name="password" class="form-control" placeholder="Enter your password">
        <?php
        if (!empty($errors['password'])) {
             echo '<div class="error-message">' . htmlspecialchars($errors['password']) . '</div>';}?>
     </div>
     <button type="submit" class="btn btn-primary w-100">Login</button>
     </form>
     <div class="text-center mt-3">
     <span>Don't have an account?</span> <a href="register.php" class="register-link">Register</a>
     </div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>