<?php
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات

// الاستعلام هادا بجيبب اسم المريض واسم الدواء والجرعة الخاصة بالدواء عن طريق ربط 3 جداول مع بعض:

// patientdrug:الى بيربط بين المرضى والادوية
// patients: فيها معلومات المرضى (زي الاسم)
// drugs: فيها معلومات الأدوية (زي الاسم والجرعة)
// يعني بيعمل ربط بين جداول المرضى والأدوية عشان يجيب بيانات المرضى مع الأدوية اللي مخصصاله
$query = "SELECT patients.name AS patient_name, drugs.name AS drug_name, drugs.dosage 
          FROM patientdrug 
          JOIN patients ON patientdrug.pat_id = patients.id 
          JOIN drugs ON patientdrug.drug_id = drugs.id";
$result = $conn->query($query); // $result تنفيذ اللاستعلام وتخزينه في المتغير
if ($result) { // اذا نجح الاستعلام
    $patient_drugs = $result->fetch_all(MYSQLI_ASSOC);//سيتم تحويل النتائج إلى مصفوفة باستخدام fetch_all(MYSQLI_ASSOC) بحيث يتم تخزين الأدوية المخصصة لكل مريض في المتغير $patient_drugs
} else {
    $patient_drugs = [];// اذا فشل الاستعلام سيتم تعيين المتغير كمصفوفة فارغة
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patients Drugs</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <style>
    body {
      font-family: 'Poppins', sans-serif;
      background-color: #f4f6f9;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 50px auto;
      background: #ffffff;
      border-radius: 15px;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
      padding: 30px;
    }
    h1 {
      font-size: 28px;
      font-weight: 600;
      color: #3a3a3a;
      text-align: center;
      margin-bottom: 20px;
      position: relative;
    }
    h1::after {
      content: "";
      display: block;
      width: 50px;
      height: 3px;
      background: #007bff;
      margin: 10px auto 0;
      border-radius: 2px;
    }
    .table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }
    .table th {
      background: linear-gradient(90deg, #007bff, #0056b3);
      color: #ffffff;
      font-weight: 500;
      padding: 12px;
      border: none;
      text-align: center;
      font-size: 14px;
    }
    .table td {
      padding: 12px;
      text-align: center;
      border-bottom: 1px solid #eeeeee;
      font-size: 14px;
    }
    .back-btn {
      display: inline-block;
      margin-top: 20px;
      padding: 10px 20px;
      font-size: 14px;
      font-weight: 500;
      color: #555555;
      background-color: #f0f0f0;
      border: none;
      border-radius: 10px;
      text-decoration: none;
      text-align: center;
      transition: background-color 0.3s ease;
    }
    .back-btn:hover {
      background-color: rgb(155, 163, 172);
    }
    .fa-pills {
      color: #007bff;
      margin-right: 8px;
    }
    .fa-prescription-bottle {
      color: #e74c3c;
      margin-right: 8px;
    }
  </style>
</head>
<body>

<div class="container">
<h1><i class="fas fa-pills"></i> Patients Drugs</h1>
<table class="table">
    <thead>
      <tr>
        <th>Patient Name</th>
        <th>Drug Name</th>
        <th>Dosage</th>
      </tr>
    </thead>
    <tbody>
      <?php if (!empty($patient_drugs)) { ?>
        <?php foreach ($patient_drugs as $entry) { ?>
          <tr>
            <td><?php echo htmlspecialchars($entry['patient_name']); ?></td>
            <td><i class="fas fa-pills"></i> <?php echo htmlspecialchars($entry['drug_name']); ?></td>
            <td><i class="fas fa-prescription-bottle"></i> <?php echo htmlspecialchars($entry['dosage']); ?> mg</td>
          </tr>
        <?php } ?>
      <?php } else { ?>
        <tr>
          <td colspan="3">No data available.</td>
        </tr>
      <?php } ?>
    </tbody>
  </table>
  <a href="doctordashboard.php" class="back-btn">
    <i class="fas fa-arrow-left"></i> Back to Dashboard
  </a> 
</div>
</body> 
</html>


