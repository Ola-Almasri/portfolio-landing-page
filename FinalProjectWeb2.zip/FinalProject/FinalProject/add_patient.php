
<?php    
include 'db.php'; // تضمين ملف الاتصال بقاعدة البيانات
session_start(); // بدء الجلسة
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'doctor') {
    header("Location: login.php"); // إذا لم يكن هناك جلسة صالحة، أعد التوجيه إلى صفحة تسجيل الدخول
    exit();
}
$errors = []; // مصفوفة لتجميع الأخطاء لكل حقل
// التحقق من الحقول وعرض رسايل الخطأ لو كانوا فارغين
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST["name"];// استرجاع الاسم 
    $email = $_POST["email"];// استرجاع البريد الإلكتروني
    $password = $_POST["password"];// استرجاع كلمة المرور
    $age = $_POST["age"];// استرجاع العمر
    $gender = $_POST["gender"];// استرجاع الجنس
    $problem = $_POST["problem"];// استرجاع وصف المشكلة
    $entranceDate = $_POST["entranceDate"];// استرجاع تاريخ الدخول
    $phone_number = $_POST["phone_number"];// استرجاع رقم الهاتف

    // التحقق من القيم المدخلة
    if (empty($name)) {// بدي افحص لو كان الاسم فارغ
        $errors['name'] = "Fullname is required.";// هتتخزن رسالة الخطأ بالمصفوفة  بانو الاسم كامل مطلوب
    }
    if (empty($email)) { // بدي افحص لو كان الايميل فارغ
        $errors['email'] = "Email is required.";// هتتخزن رسالة الخطأ بالمصفوفة  بانو الايميل مطلوب
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {// بدي اتحقق هل الايميل يلي دخلو المستخدم صالح
        $errors['email'] = "Invalid email format.";// ولو مش صالح هتتخزن رسالة الخطأ بالمصفوفة
    }
    if (empty($password)) {// بدي افحص لو كان الباسوورد فارغ
        $errors['password'] = "Password is required.";// هتتخزن رسالة الخطأ بالمصفوفة  بانو الباسوورد مطلوب
    }
    if (empty($age) || !is_numeric($age) || $age <= 0) {//  بدي افحص لو كان العمر فارغ او اقل او يساوي صفر
        $errors['age'] = "Valid age is required.";// هتتخزن رسالة الخطأ بالمصفوفة لو تحقق احدى الشرطين  بانو العمر مطلوب
    }
    if (empty($gender) || !in_array(strtolower($gender), ['male', 'female'])) {// بدي اتحقق من اختيار جنس صحيح
        $errors['gender'] = "Gender must be 'male' or 'female'.";// لو لم يتم اختيار جنس معين سيتم عرض رسالة الخطأ بانو لازم اختار جنس معين
    }
    if (empty($problem)) {// بدي افحص لو المشكلة كانت فارغة
        $errors['problem'] = "Problem description is required.";// سيتم عرض رسالة الخطأ بانو المشكلة مطلوبة
    }
    if (empty($entranceDate) || !strtotime($entranceDate)) {// بدي اتحقق من إدخال تاريخ دخول صحيح
        $errors['entranceDate'] = "Valid entrance date is required.";
    }
    if (empty($phone_number)) {// بدي اتحقق لو رقم الهاتف كان فارغ
        $errors['phone_number'] = "Phone number is required.";
    }

    // التحقق من البريد الإلكتروني في جدول patients فقط
    if (empty($errors)) {
        $check_email_sql = "SELECT * FROM patients WHERE email = '$email'";
        $check_email_result = $conn->query($check_email_sql);

        if ($check_email_result->num_rows > 0) {
            $errors['email'] = "This email is already registered in patients table."; // إذا كان البريد موجودًا مسبقًا
        }
    }
    // سيتم تنفيذ العملية لو ما كان عندي أخطاء
    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

         // إدخال بيانات المريض في جدول المرضى
        $sql_patient = "INSERT INTO patients (name, email, password, age, gender, problem, entranceDate, phone_number) 
                        VALUES ('$name', '$email', '$hashed_password', $age, '$gender', '$problem', '$entranceDate', '$phone_number')";

        if ($conn->query($sql_patient)) {// التحقق من نجاح إدخال البيانات
            $patient_id = $conn->insert_id; // الحصول على اي دي المريض الجديد

            $_SESSION['patient_id'] = $patient_id; //تخزين اي دي المريض في الجلسة
            $_SESSION['patient_name'] = $name; // تخزين اسم المريض في الجلسة

            // إضافة المريض إلى جدول users
            $role = 'patient';
            $sql_user = "INSERT INTO users (name, email, password, phone_number, role) 
                         VALUES ('$name', '$email', '$hashed_password', '$phone_number', '$role')";

            if ($conn->query($sql_user)) {
                // إضافة العلاقة بين الطبيب والمريض في جدول patientdoctor
                $doctor_id = $_SESSION['user_id'];
                $relation_sql = "INSERT INTO patientdoctor (pat_id, doc_id) 
                                 VALUES ($patient_id, $doctor_id)";
                if ($conn->query($relation_sql)) {
                    // إعادة التوجيه إلى صفحة الدكتور مع رسالة النجاح
                    header("Location: doctordashboard.php?success=patient added successfully");
                    exit();// إنهاء السكريبت
                } else {
                    $errors['general'] = "Failed to create doctor-patient relation: " . $conn->error;
                }
            } else {// إذا فشل الاستعلام الخاص بإضافة مريض إلى جدول اليوزر
                $errors['general'] = "Failed to add patient to users table: " . $conn->error;
            }
        } else {// إذا فشل الاستعلام الخاص بإضافة مريض إلى جدول المرضى
            $errors['general'] = "Failed to add patient to patients table: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Patient</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa; 
            font-family: 'Poppins', Arial, sans-serif;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-top: 40px; 
        }
        .add-patient-container {
            background-color: #cce5ff;
            padding: 30px;
            border-radius: 20px;
            max-width: 600px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        .add-patient-header {
            font-size: 24px;
            font-weight: bold;
            color: #004085;
            margin-bottom: 20px;
            text-align: center;
        }
        .form-label {
            font-size: 14px;
            font-weight: 500;
            color: #6c757d;
        }
        .form-control, .form-select {
            border-radius: 10px; 
            font-size: 14px; 
            height: 40px; 
        }
        .form-control {
            border-radius: 10px; 
        }
        .required {
            color: red;
            font-size: 16px;
            font-weight: bold;
        }
        .btn-add {
            background-color: #004085; 
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 20px;
            font-weight: bold;
            transition: background-color 0.3s ease;
        }
        .btn-add:hover {
            background-color: rgb(109, 158, 211);
        }
        .text-danger {
            font-size: 12px; 
        }
    </style>
</head>
<body>
<div class="add-patient-container">
    <h1 class="add-patient-header">Add Patient</h1>
    <form action="add_patient.php" method="POST">
        <?php
        //التحقق  إذا كان عندي رسالة خطأ عامة
        if (isset($errors['general']) && $errors['general'] != '') {
            echo '<div class="alert alert-danger">' . htmlspecialchars($errors['general']) . '</div>';
        }
        ?>

        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Full Name: <span class="required">*</span></label>
                <input type="text" name="name" class="form-control" placeholder="Enter full name"
                       value="<?php if (isset($name)) echo htmlspecialchars($name); ?>">
                <?php
                if (isset($errors['name']) && $errors['name'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['name']) . '</span>';
                }
                ?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Email Address: <span class="required">*</span></label>
                <input type="email" name="email" class="form-control"  placeholder="Enter email address"
                       value="<?php if (isset($email)) echo htmlspecialchars($email); ?>">
                <?php
                if (isset($errors['email']) && $errors['email'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['email']) . '</span>';
                }
                ?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Password: <span class="required">*</span></label>
                <input type="password" name="password" class="form-control" placeholder="Enter password">
                <?php
                if (isset($errors['password']) && $errors['password'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['password']) . '</span>';}?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Age: <span class="required">*</span></label>
                <input type="number" name="age" class="form-control" placeholder="Enter age"
                       value="<?php if (isset($age)) echo htmlspecialchars($age); ?>">
                <?php
                if (isset($errors['age']) && $errors['age'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['age']) . '</span>';}?>
            </div>
            <div class="col-md-6">
              <label class="form-label">Gender: <span class="required">*</span></label>
              <select name="gender" class="form-select">
              <option value="" <?php if (!isset($gender) || $gender == '') echo 'selected'; ?>>Select Gender</option>
              <option value="male" <?php if (isset($gender) && $gender == 'male') echo 'selected'; ?>>Male</option>
              <option value="female" <?php if (isset($gender) && $gender == 'female') echo 'selected'; ?>>Female</option>
              </select>
              <?php
               if (isset($errors['gender']) && $errors['gender'] != '') {
               echo '<span class="text-danger">' . htmlspecialchars($errors['gender']) . '</span>';}?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Phone Number: <span class="required">*</span></label>
                <input type="text" name="phone_number" class="form-control" placeholder="Enter phone number"
                       value="<?php if (isset($phone_number)) echo htmlspecialchars($phone_number); ?>">
                <?php
                if (isset($errors['phone_number']) && $errors['phone_number'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['phone_number']) . '</span>';}?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Entrance Date: <span class="required">*</span></label>
                <input type="date" name="entranceDate" class="form-control"
                       value="<?php if (isset($entranceDate)) echo htmlspecialchars($entranceDate); ?>">
                <?php
                if (isset($errors['entranceDate']) && $errors['entranceDate'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['entranceDate']) . '</span>';}?>
            </div>
            <div class="col-md-6">
                <label class="form-label">Problem Description: <span class="required">*</span></label>
                <textarea name="problem" class="form-control" placeholder="Describe the problem"><?php
                    if (isset($problem)) echo htmlspecialchars($problem); ?></textarea>
                <?php
                if (isset($errors['problem']) && $errors['problem'] != '') {
                    echo '<span class="text-danger">' . htmlspecialchars($errors['problem']) . '</span>';}?>
            </div>
        </div>
        <div class="text-center mt-4">
            <button type="submit" name="add_patient" class="btn btn-add">Add Patient</button>
        </div>
    </form>
</div>
</body>
</html>







