function setYear() {
  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }
}

function handleSubmit(e) {
  e.preventDefault();
  alert("This is a static demo. Connect this form to a backend or service to receive messages.");
}

function setupSmoothScroll() {
  const links = document.querySelectorAll('a.nav-link[href^="#"]');
  links.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const targetId = link.getAttribute("href").substring(1);
      const target = document.getElementById(targetId);
      if (target) {
        target.scrollIntoView({ behavior: "smooth" });
      }
    });
  });
}

document.addEventListener("DOMContentLoaded", () => {
  setYear();
  setupSmoothScroll();
});
